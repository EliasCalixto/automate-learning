def promedio(ep1,ep2):
    print(f'su promedio es {(ep1+ep2)/2}')