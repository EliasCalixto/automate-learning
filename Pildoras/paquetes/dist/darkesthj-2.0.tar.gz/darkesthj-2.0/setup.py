from setuptools import setup

setup(
    name='darkesthj',
    version='2.0',
    description='gaaa',
    author='darkesthj',
    packages=['darkesthj','darkesthj']
)