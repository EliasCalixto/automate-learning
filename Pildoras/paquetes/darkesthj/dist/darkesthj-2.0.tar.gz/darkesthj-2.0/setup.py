from setuptools import setup

setup(
    name='darkesthj',
    version='2.0',
    description='the coolest package',
    author='Elias Calixto',
    author_email='eliascalixto989@gmail.com',
    url='eliascalixto.me',
    packages=['herramientas','herramientas.isil']
)
